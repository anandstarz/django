from scrapy.spider import BaseSpider
from scrapy.http import Request
from urlparse import urljoin
from scrapy.selector import HtmlXPathSelector
from bing.items import BingItem
import urllib
import urllib2
	
class bingg(BaseSpider):
	output=[]
	name = "bnggqqq"
	start_urls=["file:///home/anandhakumar/ScrapyProjects/bing_c/outpu.html"]
	
	
	def parse(self, response):
		
		
		hxs=HtmlXPathSelector(response)


		y    = [l.strip() for l in open('input.csv','r').readlines()]	

		for i in range(len(y)):
			url = 'http://e-mailvalidator.com/index.php'
			user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
			values = {'EMAIL' : '%s'%y[i] }
			headers = { 'User-Agent' : user_agent }

			data = urllib.urlencode(values)
			req = urllib2.Request(url, data, headers)
			response = urllib2.urlopen(req)

			the_page = response.read()

			file = open('outpu.html','w')
			file.write(the_page)
			file.close()
	
			p_url='file:///home/anandhakumar/ScrapyProjects/bing_c/outpu.html'
		   	if p_url:
				yield Request(p_url, callback=self.parse_sub, dont_filter=True)



	def parse_sub(self, response):
         
		print "***************Sub Parse Called********************"
		hxs = HtmlXPathSelector(response)

		mail = hxs.select('//h1/text()').extract()[1].encode('utf-8').split(' ')[0].strip()
	
		status = hxs.select('//h1/b/text()').extract()[0].encode('utf-8').strip()

		s=str(mail+'\t'+status)+'\n'
		print s
		self.output.append(s)

		self.fun(self.output)

	def fun(self,r):
		print "finished"
		result=r
		filehandle = open('Email_status.tsv','w')
		filehandle.write("Mail_ID\tStatus\n")
		for i in result:
			filehandle.write("%s"%i)



