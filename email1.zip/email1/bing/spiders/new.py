from scrapy.spider import BaseSpider
from scrapy.http import Request
from urlparse import urljoin
from scrapy.selector import HtmlXPathSelector
from bing.items import BingItem
import urllib
import urllib2
import cookielib
	
class bingg(BaseSpider):
	output=[]
	name = "ema"
	start_urls=["file:///home/anandhakumar/ScrapyProjects/email1/outpu.html"]
	
	
	def parse(self, response):
		
		
		hxs=HtmlXPathSelector(response)


		y    = [l.strip() for l in open('input.csv','r').readlines()]	

		for i in range(len(y)):

			cj = cookielib.CookieJar()
			#create an opener
			opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))


			opener.addheaders.append(('User-agent', 'Mozilla/4.0'))
			opener.addheaders.append( ('Referer', 'https://www.hscripts.com/tools/mailid-validation/') )

			login_data = urllib.urlencode({'email' : '%s'%y[i], 'start' : 'go'})

			resp = opener.open('https://www.hscripts.com/tools/mailid-validation/', login_data)
			the_page = resp.read()

			file = open('outpu.html','w')
			file.write(the_page)
			file.close()
			resp.close()

	
			p_url='file:///home/anandhakumar/ScrapyProjects/email1/outpu.html'
		   	if p_url:
				yield Request(p_url, callback=self.parse_sub, dont_filter=True)



	def parse_sub(self, response):
         
		print "***************Sub Parse Called********************"
		hxs = HtmlXPathSelector(response)

		mail = hxs.select('//form[@name="email-ver"]/span/text()').extract()[0].encode('utf-8').replace('\xc2','').replace('\xa0','').split(' ')[0].strip()
		
		try:
			x=hxs.select('//form[@name="email-ver"]/span/text()').extract()[0].encode('utf-8').replace('\xc2','').replace('\xa0','').split('is')[1].strip()
						
			if 'Invalid' in x:
				status = 'Invalid'
			else:
				status = 'valid'
		except:
			status = 'Invalid'
		s=str(mail+'\t'+status)+'\n'
		print s
		self.output.append(s)

		self.fun(self.output)

	def fun(self,r):
		print "finished"
		result=r
		filehandle = open('Email_status.tsv','w')
		filehandle.write("Mail_ID\tStatus\n")
		for i in result:
			filehandle.write("%s"%i)



